The height of the bay is equal to container height + 2;
And truck equals to -1 meanning that there is no truck stack in this instance